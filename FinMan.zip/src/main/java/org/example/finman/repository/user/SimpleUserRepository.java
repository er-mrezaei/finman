package org.example.finman.repository.user;

public interface SimpleUserRepository extends UserRepository {
}