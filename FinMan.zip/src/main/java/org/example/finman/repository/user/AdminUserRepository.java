package org.example.finman.repository.user;

public interface AdminUserRepository extends UserRepository {
  }