package org.example.finman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinManApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinManApplication.class, args);
    }

}
